package niam;

public class Class4 {

	public int x;
	protected String y;
	
	private Class4(int x, String y) {
		super();
		this.x = x;
		this.y = y;
	}
}
