package niam;

public class Class3 {

	private int a;
	private int b;
	private String c;
	
	public Class3(int a, int b, String c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public String getC() {
		return c;
	}
}
