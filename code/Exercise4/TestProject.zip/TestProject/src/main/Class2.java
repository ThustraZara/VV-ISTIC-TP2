package main;

public class Class2 {

	private int x;
	private String y;
	private char z;
	
	public int getX() {
		return x;
	}

	protected String getY() {
		return y;
	}

	protected char getZ() {
		return z;
	}

	public Class2(int x, String y, char z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	
}
