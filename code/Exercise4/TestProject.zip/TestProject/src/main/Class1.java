package main;

public class Class1 {

	private int publicInt;
	private int privateInt;
	
	private String publicString;
	private String privateString;
	
	public int getPublicInt() {
		return publicInt;
	}

	public String getPublicString() {
		return publicString;
	}

	public Class1(int publicInt, int privateInt, String publicString, String privateString) {
		super();
		this.publicInt = publicInt;
		this.privateInt = privateInt;
		this.publicString = publicString;
		this.privateString = privateString;
	}
	
}
