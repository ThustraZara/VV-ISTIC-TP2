package test;

public class Class5 {

	private int abc;
	private String def;
	
	public Class5(int abc, String def) {
		super();
		this.abc = abc;
		this.def = def;
	}
	
	protected int getAbc() {
		return abc;
	}
	protected void setAbc(int abc) {
		this.abc = abc;
	}
	protected String getDef() {
		return def;
	}
	protected void setDef(String def) {
		this.def = def;
	}
}
