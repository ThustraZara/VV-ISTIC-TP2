package test;

public class Class6 {

	private int x;
	private int y;
	private int z;
	
	private String a;
	private String b;
	private String c;

	protected int getX() {
		return x;
	}

	protected void setX(int x) {
		this.x = x;
	}

	protected int getY() {
		return y;
	}

	protected void setY(int y) {
		this.y = y;
	}

	protected int getZ() {
		return z;
	}

	protected void setZ(int z) {
		this.z = z;
	}

	private String getA() {
		return a;
	}

	private void setA(String a) {
		this.a = a;
	}

	private String getB() {
		return b;
	}

	private void setB(String b) {
		this.b = b;
	}

	private String getC() {
		return c;
	}

	private void setC(String c) {
		this.c = c;
	}

	public Class6(int x, int y, int z, String a, String b, String c) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	
}
